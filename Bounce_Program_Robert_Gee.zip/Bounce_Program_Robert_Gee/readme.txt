"""
    Hypothesis: The Brazil Nut effect is harder to visualize with larger containers. This could be
    because it takes longer to fill the empty spaces in the bottom of the container.

    Controls: Rotate with the w,a,s,d keys.
              Restart with larger container: q key.
              Restart with smaller container: e key.
"""
